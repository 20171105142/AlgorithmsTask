#include<iostream>
#include<string>
#include<stack>
using namespace std;

// 排序类
class Sort {
    public:
        void BubbleSort(int* a, int n);
        void QuickSort(int* a, int low, int high);
        void QuickSortNotRec(int* a, int low, int high);
        void HeapSort(int* a, int n);
        void HeapSortNotRec(int* a, int n);
};

// 冒泡排序
void Sort::BubbleSort(int* a, int n){
    int temp;
    for(int i = 0; i < n-1; i++)
        for(int j = n - 1; j > i; j--)
            if(a[j-1] > a[j]){
                temp = a[j-1];
                a[j-1] = a[j];
                a[j] = temp;
            }  
}

// 计算基准
int Partition(int* a, int low, int high){
    int pivot = a[low];
    while(low < high) {
        while(low < high && a[high] >= pivot)
            high--;
        a[low] = a[high];
        while(low < high && a[low] <= pivot)
            low++;
        a[high] = a[low];
    }
    a[low] = pivot;
    return low;
}

// 递归快速排序
void Sort::QuickSort(int* a, int low, int high){
    if(low < high){
        int pivotpos = Partition(a, low, high);
        QuickSort(a, low, pivotpos-1);
        QuickSort(a, pivotpos+1,high);
    }
}

// 非递归快排
void Sort::QuickSortNotRec(int* a, int low, int high){
    stack<int> s;
    if(low < high){
        int pivotpos = Partition(a, low, high);
        if(low < pivotpos-1){
            s.push(low);
            s.push(pivotpos-1);
        }
        if(pivotpos+1 < high){
            s.push(pivotpos+1);
            s.push(high);
        }
        while(!s.empty()){
            int tmpHigh = s.top();
            s.pop();
            int tmpLow = s.top();
            s.pop();
            pivotpos = Partition(a, tmpLow, tmpHigh);
            if(tmpLow < pivotpos-1){
                s.push(tmpLow);
                s.push(pivotpos-1);
            }
            if(pivotpos+1 < tmpHigh){
                s.push(pivotpos+1);
                s.push(tmpHigh);
            }
        }
    }
}

// 堆调整（非递归）
void adjustHeapNotRec(int* a, int i, int n){
    int temp = a[i];
    for(int j = i*2+1; j < n; j = j*2+1){
        if(j+1 < n && a[j] < a[j+1]){
            j++;
        }
        if(a[j] > temp){
            a[i] = a[j];
            i = j;
        } else {
            break;
        }
    }
    a[i] = temp;
}

// 堆排序（非递归）
void Sort::HeapSortNotRec(int* a, int n){
    int temp;
    for(int i = n/2-1; i >= 0; i--){
        adjustHeapNotRec(a, i, n);
    }
    for(int j = n-1; j > 0; j--){
        temp = a[0];
        a[0] = a[j];
        a[j] = temp;
        adjustHeapNotRec(a, 0, j);
    }
}

// 堆调整（递归）
void adjustHeap(int* a, int i, int n) {
    // 将最大元素设置为堆顶元素
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    int temp;
    // 如果 left 比 root 大的话
    if (left < n && a[left] > a[largest])
        largest = left;

    // I如果 right 比 root 大的话
    if (right < n && a[right] > a[largest])
        largest = right;

    if (largest != i) {
        temp = a[i];
        a[i] = a[largest];
        a[largest] = temp;
        // 递归地定义子堆
        adjustHeap(a, n, largest);
    }
}

// 堆排序（递归）
void Sort::HeapSort(int* a, int n) {
    int temp;
    for(int i = n/2-1; i >= 0; i--){
        adjustHeap(a, i, n);
    }
    for(int j = n-1; j > 0; j--){
        temp = a[0];
        a[0] = a[j];
        a[j] = temp;
        adjustHeap(a, 0, j);
    }
}