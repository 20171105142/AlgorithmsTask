#include<iostream>
#include<string>
#include "sort.h"
#include<time.h>
void initialSortNumber(int* a, int n){
    for(int i = 0 ; i < n; i++){
        // 从0-200000随机生成n个数
        a[i] = rand() % 200000;
    }
}
int main(){
    Sort sort;
    int n;
    cout << "Please enter the number of sorted numbers:";
    cin >> n;
    int a[n];
    // 初始化随机数
    initialSortNumber(a, n);

    // 冒泡排序运行时间
    clock_t begin_time = clock( );
    sort.BubbleSort(a, n);
    float seconds = float(clock( ) - begin_time) / 1000;
    cout << "The BubbleSort time is:" << seconds << "s." << endl << endl;

    initialSortNumber(a, n);

    // 堆排序（递归）运行时间
    begin_time = clock( );
    sort.HeapSort(a, n);
    seconds = float(clock( ) - begin_time) / 1000;
    cout << "The HeapSort time is:" << seconds << "s." << endl << endl;

    initialSortNumber(a, n);
    
    // 堆排序（非递归）运行时间
    begin_time = clock( );
    sort.HeapSortNotRec(a, n);
    seconds = float(clock( ) - begin_time) / 1000;
    cout << "The HeapSortNotRec time is:" << seconds << "s." << endl << endl;

    initialSortNumber(a, n);

    // 快速排序（递归）运行时间
    begin_time = clock( );
    sort.QuickSort(a, 0, n-1);
    seconds = float(clock( ) - begin_time) / 1000;
    cout << "The QuickSort time is:" << seconds << "s." << endl << endl;

    initialSortNumber(a, n);

    // 快速排序（非递归）运行时间
    begin_time = clock( );
    sort.QuickSortNotRec(a, 0, n-1);
    seconds = float(clock( ) - begin_time) / 1000;
    cout << "The QuickSortNotRec time is:" << seconds << "s." << endl << endl;
    
    

    



    system("pause");
}
