#include <string>
using namespace std;
// 单词距离类
class WordDistance{
    private:
        string word;
        int distance;
    public:
        void setWord(string word);
        void setDistance(int distance);
        int getDistance();
        string getWord();
};
void WordDistance::setWord(string word){
    this->word = word;
}
void WordDistance::setDistance(int distance){
    this->distance = distance;
}
int WordDistance::getDistance(){
    return distance;
}
string WordDistance::getWord(){
    return word;
}
