#include <iostream>
#include <string>
#include <fstream>
#include "word.h"
#include "wordDistance.h"
using namespace std;
#define ARRAYSIZE  14251
// 哈希类
class HashTemplate {
    private:
        int itemCount;
        Word hashArrary[ARRAYSIZE];
    public:
        void initHash();
        int insert(Word item);
        int deleteWord(string item);
        void printHash();
        Word query(string item);
        int ASL();
        double calFillFactor();
        void searchAllWord(string wrong);
};
// 初始化
void HashTemplate::initHash() {
    for(int i = 0; i < ARRAYSIZE; i++){
        hashArrary[i].setWord("");
        hashArrary[i].setTrans("");
        hashArrary[i].setState(EMPTY);
        hashArrary[i].setConflict(0);
    }
    itemCount = 0;
};

// 转换为小写单词
string switchLower(string word){
    string temp;
    for(int i = 0; i < word.length(); i++){
        temp += tolower(word[i]);
    }
    return temp;
}
// 计算哈希值
int createHash(string word){
    int count = 0;
    for(int i = 0; i < word.length(); i++){
        count += word[i];
    }
    return count * count % ARRAYSIZE;
}
// 插入元素
int HashTemplate::insert(Word item){
    if(itemCount == ARRAYSIZE + 1)
        return -1;
    int conflict = 0;
    item.setWord(switchLower(item.getWord()));
    int key = createHash(item.getWord());
    // 存在冲突
    while(hashArrary[key].getState() == EXIST){
        key++;
        conflict++;
        if(key >= ARRAYSIZE - 1)
            key %= ARRAYSIZE;
    }
    item.setConflict(conflict);
    item.setState(EXIST);
    hashArrary[key] = item;
    itemCount++;
    return key;
}
// 打印哈希表
void HashTemplate::printHash(){
    for(int i = 0; i < ARRAYSIZE; i++){
        if(hashArrary[i].getState() == EXIST){
            cout << i << ' ';
            cout << hashArrary[i].getWord() << ' ';
            cout << hashArrary[i].getTrans() << ' ';
            cout << hashArrary[i].getConflict() << endl;
        }
    }
}
// 查询
Word HashTemplate::query(string word){
    Word tmpWord;
    word = switchLower(word);
    int key = createHash(word);
    // 存在冲突
    while(hashArrary[key].getState() != EMPTY){
        if(hashArrary[key].getWord() == word){
            tmpWord = hashArrary[key];
            return tmpWord;
        } else {
            key++;
        }
        if(key >= ARRAYSIZE - 1)
            key %= ARRAYSIZE;
    }
    return tmpWord;
}
// 删除
int HashTemplate::deleteWord(string word){
    word = switchLower(word);
    int key = createHash(word);
    // 存在冲突
    while(hashArrary[key].getState() == EXIST){
        if(hashArrary[key].getWord() == word){
            hashArrary[key].setWord("");
            hashArrary[key].setTrans("");
            hashArrary[key].setState(DELETE);
            itemCount--;
        } else{
            key++;
        }
        if(key >= ARRAYSIZE - 1)
            key %= ARRAYSIZE;
    }
    
    return key;
}
// 计算ASL
int HashTemplate::ASL(){
    int count = 0;
    for(int i = 0; i < ARRAYSIZE; i++){
        if(hashArrary[i].getState() == EXIST)
            count += hashArrary[i].getConflict() + 1;
    }
    return count / itemCount;
}

// 计算装填因子
double HashTemplate::calFillFactor(){
    return (double)itemCount / ARRAYSIZE;
}

// 在当前位置的前一行、前一列、前对角线中找最小值
int findMinimum(int lastrow, int lastcol, int diagonal){
    int temp = lastrow < lastcol ? lastrow : lastcol;
    int result = temp < diagonal ? temp : diagonal;
    return result;
}

// 递归快速排序
int Partition(WordDistance *wordDistance, int low, int high){
    WordDistance pivot = wordDistance[low];
    while(low < high) {
        while(low < high && wordDistance[high].getDistance() >= pivot.getDistance())
            high--;
        wordDistance[low] = wordDistance[high];
        while(low < high && wordDistance[low].getDistance() <= pivot.getDistance())
            low++;
        wordDistance[high] = wordDistance[low];
    }
    wordDistance[low] = pivot;
    return low;
}
void QuickSort(WordDistance *wordDistance, int low, int high){
    if(low < high){
        int pivotpos = Partition(wordDistance, low, high);
        QuickSort(wordDistance, low, pivotpos-1);
        QuickSort(wordDistance, pivotpos+1,high);
    }
}

// 计算两个单词的编辑距离
int calculateEditDistance(string wrong, string search){
    int wrongLength = wrong.length();
    int searchLength = search.length();
    int editDistance[searchLength+1][wrongLength+1];
    for(int i = 0; i <= wrongLength; i++)
        editDistance[0][i] = i;
    for(int j = 0; j <= searchLength; j++)
        editDistance[j][0] = j;
    for(int i = 1; i <= searchLength; i++){
        for(int j = 1; j <= wrongLength; j++){
            if(search[i-1] == wrong[j-1])
                editDistance[i][j] = editDistance[i-1][j-1];
            else
                editDistance[i][j] = findMinimum(editDistance[i-1][j]+1, 
                                    editDistance[i][j-1]+1, 
                                    editDistance[i-1][j-1]+1);
        }
    }
    // cout << "Distance matrix" << endl;
    // cout << "    ";
    // for(int i = 0; i < wrongLength; i++)
    //     cout << wrong[i] << " ";
    // cout << endl;
    // for(int j = 0; j <= searchLength; j++){
    //     if(j > 0)
    //         cout << search[j-1] << " ";
    //     else
    //         cout << "  ";
    //     for(int i = 0; i <= wrongLength; i++){
    //         cout << editDistance[j][i] << " ";
    //     }
    //     cout << endl;
    // }
    // cout << wrong << " and " << search << "edit distance is " << editDistance[searchLength][wrongLength] << endl;
    return editDistance[searchLength][wrongLength];
}

// int main(){
//     calculateEditDistance("fragmenta", "fragment");
//     system("pause");
// }

// 遍历所有单词找最小编辑距离
void HashTemplate::searchAllWord(string wrong){
    WordDistance wordDistance[itemCount];
    for(int i = 0, j = 0; i < ARRAYSIZE; i++){
        if(hashArrary[i].getState() == EXIST){
            wordDistance[j].setWord(hashArrary[i].getWord());
            wordDistance[j++].setDistance(
                calculateEditDistance(wrong, hashArrary[i].getWord()));
        }
    }
    QuickSort(wordDistance, 0, itemCount);
    for(int i = 0; i < 3; i++){
        cout << "The words you are looking for may be ";
        cout << wordDistance[i].getWord() << "(" ;
        cout << wordDistance[i].getDistance() << ").";
        cout << endl;
    }
}

