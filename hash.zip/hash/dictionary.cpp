#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
#include "hash.h"
using namespace std;

// 计算数据总量
int statisticData(string fileName){
    ifstream file;
    file.open(fileName);
    string data;
    int count = 0;
    while(getline(file, data, '\n')){
        count++;
    }
    file.close();
    return count;
}
// 处理一行数据
Word read(string lineData){
    Word word;
    bool flag = true;
    string temp = "";
    int index;
    string coprData = lineData;
    for(int i = 0; i < lineData.length(); i++){
        if(lineData[i] != ' '){
            temp += lineData[i];
        } else {
            word.setWord(temp);
            index = i + 1;
            temp = "";
            break;
        }
    }
    for(int i = index; i < lineData.length(); i++){
        temp += lineData[i];
    }
    word.setTrans(temp);
    return word;
}
// 读取数据
void readData(HashTemplate &hash){
    Word word;
    string lineData;
    ifstream file;
    int index;
    int count = 0;
    string fileName = "data.txt";
    int countData = statisticData(fileName);
    file.open(fileName);
    while(getline(file, lineData, '\n')){
        word = read(lineData);
        index = hash.insert(word);
        if (index == -1) {
            cout << "Hash full" << endl;
        } else {
            cout << "\rRead " << ++count << "/";
            cout << countData << " " << word.getWord();
        }
    }
    cout << endl;
    file.close();
}
int main(){
    cout << "-----------------Hash Dictionary-----------------" << endl;
    HashTemplate hash;
    Word insertWord;
    Word queryWord;
    int selectOrder;
    string temp;
    // 函数返回代码
    int code;
    const clock_t begin_time = clock( );
    // for(int i = 0; i < 5; i++){
    //     hash.initHash();
    //     readData(hash);
    // }
    // float seconds = float(clock( ) - begin_time) / 1000 / 5;
    hash.initHash();
    readData(hash);
    float seconds = float(clock( ) - begin_time) / 1000;
    cout << "The creation time is:" << seconds << "s" << endl;
    while(1){
        cout << "-----------------Hash Dictionary-----------------" << endl;
        cout << "\t\t1 print hash dictionary" << endl;
        cout << "\t\t2 insert word" << endl;
        cout << "\t\t3 delete word" << endl;
        cout << "\t\t4 query word" << endl;
        cout << "\t\t5 ASL" << endl;
        cout << "\t\t6 fill factor" << endl;
        cout << "\t\t0 quit" << endl;
        cout << "enter serial number:";
        cin >> selectOrder;
        switch(selectOrder){
            case 1:
                cout << "**********************print*************************" << endl;
                hash.printHash();
                break;
            case 2:
                cout << "**********************insert************************" << endl;
                cout << "enter insert word:";
                temp = "";
                cin >> temp;
                insertWord.setWord(temp);
                cout << "enter insert translation:";
                temp = "";
                cin >> temp;
                insertWord.setTrans(temp);
                code = hash.insert(insertWord);
                if(code == -1)
                    cout << "hash full" << endl;
                else {
                    cout << insertWord.getWord() << " ";
                    cout << "insert position " << code << endl;
                }
                break;
            case 3:
                cout << "**********************delete************************" << endl;
                cout << "enter delte word:";
                temp = "";
                cin >> temp;
                code = hash.deleteWord(temp);
                if(code == -1)
                    cout << "delete failed" << endl;
                else
                    cout << "delete position " << code << endl;
                break;
            case 4:
                cout << "**********************query************************" << endl;
                cout << "enter query word:";
                temp = "";
                cin >> temp;
                queryWord = hash.query(temp);
                if(queryWord.getWord() == ""){
                    hash.searchAllWord(temp);
                    // cout << "query failed" << endl;
                } else {
                    cout << queryWord.getWord() << " ";
                    cout << queryWord.getTrans() << endl;
                }
                break;
            case 5:
                cout << "**********************ASL************************" << endl;
                cout << "ASL:" << hash.ASL() << endl;
                break;
            case 6:
                cout << "******************Load Factor********************" << endl;
                cout << "a:" << fixed << setprecision(2) << hash.calFillFactor() << endl;
                break;
            default:
                break;
        }
    }
    system("pause");
}