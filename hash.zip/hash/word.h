#include<string>
using namespace std;
// 单词状态
enum State{
    EMPTY,
    EXIST,
    DELETE
};
// 单词类
class Word{
    private:
        int conflict;
        string word;
        string trans;
        State state;
    public:
        void setWord(string word);
        void setTrans(string trans);
        void setConflict(int conflict);
        void setState(State state);
        int getConflict();
        string getWord();
        string getTrans();
        State getState();
};
void Word::setState(State state){
    this->state = state;
}
void Word::setConflict(int conflict){
    this->conflict = conflict;
}
void Word::setWord(string word){
    this->word = word;
}
void Word::setTrans(string trans){
    this->trans = trans;
}
int Word::getConflict(){
    return conflict;
}
string Word::getWord(){
    return word;
}
string Word::getTrans(){
    return trans;
}
State Word::getState(){
    return state;
}
